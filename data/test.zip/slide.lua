Slide = class(UIElement)

function Slide:ctor()
    self:enableLifeCircleCallback(true)
    self.currentPage = 0
    self.animationTime = 0.0
    self.firstInit = true

    self.photoSpriteFrames = {}
    for index = 1, 9 do
        local texture = Texture2D.createWithFile(gResourceRootPath.."/photos/photo"..tostring(math.floor(index))..".jpg", false)
        local spriteFrame = SpriteFrame.createWithTexture(texture)
        spriteFrame:retain()
        table.insert(self.photoSpriteFrames, spriteFrame)
    end

    self.photo1 = UIImage.create()
    __gCanvas:addChild(self.photo1)
    self.label1 = UILabel.create()
    self.label1:setTTFFontSource(gResourceRootPath.."/cute.ttf")
    self.label1:setFontSize(38.0)
    self.label1:enableOutline(Color4B.new(0, 0, 0, 255), 1)
    self.label1:setColor(Color3B.new(255, 192, 68))
    self.label1:setTextAlignment(UILabelTextAlignment.UILABEL_TEXTALIGNMENT_CENTER, UILabelTextAlignment.UILABEL_TEXTALIGNMENT_CENTER)
    __gCanvas:addChild(self.label1)

    self.photo2 = UIImage.create()
    self.photo2:setVisible(false)
    __gCanvas:addChild(self.photo2)
    self.label2 = UILabel.create()
    self.label2:setVisible(false)
    self.label2:setTTFFontSource(gResourceRootPath.."/cute.ttf")
    self.label2:setFontSize(42.0)
    self.label2:enableOutline(Color4B.new(0, 0, 0, 255), 1)
    self.label2:setColor(Color3B.new(255, 192, 68))
    self.label2:setTextAlignment(UILabelTextAlignment.UILABEL_TEXTALIGNMENT_CENTER, UILabelTextAlignment.UILABEL_TEXTALIGNMENT_CENTER)
    __gCanvas:addChild(self.label2)

    _pageTimestamps = {}
    for index = 1, 11 do
        table.insert(_pageTimestamps, index * 4000)
    end
end

function Slide:onUpdate()
    if self.firstInit then
        self.firstInit = false
        self.currentPage = 0
        self.animationTime = 0.0
    else
        self.animationTime = self.animationTime + gTimeSinceLastFrame
    end

    if self.animationTime < _pageTimestamps[1] then -- 前10秒
        if self.currentPage == 0 then
            self.currentPage = 1
            self.photo2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo1:setVisible(true)
            self.label1:setVisible(true)
            self.photo1:setOpacity(0)
            self.label1:setOpacity(0)
            self.photo1:runAction(FadeIn.create(1500))
            self.label1:runAction(FadeIn.create(1500))

            self.photo1:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo1:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo1:setPosition(Vector2.new(__gWidth / 3.0, __gHeight / 2))
            self.label1:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label1:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label1:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label1:setString("2013年6月16日 夜\n在好友的鼓动下，我们电话中确定关系")
        end
    elseif self.animationTime < _pageTimestamps[2] then
        if self.currentPage == 1 then
            self.currentPage = 2
            self.photo1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo2:setVisible(true)
            self.label2:setVisible(true)
            self.photo2:setOpacity(0)
            self.label2:setOpacity(0)
            self.photo2:runAction(FadeIn.create(1500))
            self.label2:runAction(FadeIn.create(1500))
            self.photo2:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo2:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo2:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label2:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label2:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label2:setPosition(Vector2.new(0.0, __gHeight / 2))
            self.label2:setString("大学期间我地偷偷摸摸到处去玩\n我拍照技术很差就是了~")
        end
    elseif self.animationTime < _pageTimestamps[3] then
        if self.currentPage == 2 then
            self.currentPage = 3
            self.photo2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo1:setVisible(true)
            self.label1:setVisible(true)
            self.photo1:setOpacity(0)
            self.label1:setOpacity(0)
            self.photo1:runAction(FadeIn.create(1500))
            self.label1:runAction(FadeIn.create(1500))
            self.photo1:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo1:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo1:setPosition(Vector2.new(__gWidth / 3.0, __gHeight / 2))
            self.label1:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label1:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label1:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label1:setString("因为异地读书，每次分别你都哭得梨花带雨")
        end
    elseif self.animationTime < _pageTimestamps[4] then
        if self.currentPage == 3 then
            self.currentPage = 4
            self.photo1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo2:setVisible(true)
            self.label2:setVisible(true)
            self.photo2:setOpacity(0)
            self.label2:setOpacity(0)
            self.photo2:runAction(FadeIn.create(1500))
            self.label2:runAction(FadeIn.create(1500))
            self.photo2:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo2:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo2:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label2:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label2:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label2:setPosition(Vector2.new(0.0, __gHeight / 2))
            self.label2:setString("后面我们拥有了自己的小车，可以更愉快地自驾游啦~")
        end
    elseif self.animationTime < _pageTimestamps[5] then
        if self.currentPage == 4 then
            self.currentPage = 5
            self.photo2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo1:setVisible(true)
            self.label1:setVisible(true)
            self.photo1:setOpacity(0)
            self.label1:setOpacity(0)
            self.photo1:runAction(FadeIn.create(1500))
            self.label1:runAction(FadeIn.create(1500))
            self.photo1:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo1:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo1:setPosition(Vector2.new(__gWidth / 3.0, __gHeight / 2))
            self.label1:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label1:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label1:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label1:setString("不知不觉，我们在一起9年了")
        end
    elseif self.animationTime < _pageTimestamps[6] then
        if self.currentPage == 5 then
            self.currentPage = 6
            self.photo1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo2:setVisible(true)
            self.label2:setVisible(true)
            self.photo2:setOpacity(0)
            self.label2:setOpacity(0)
            self.photo2:runAction(FadeIn.create(1500))
            self.label2:runAction(FadeIn.create(1500))
            self.photo2:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo2:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo2:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label2:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label2:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label2:setPosition(Vector2.new(0.0, __gHeight / 2))
            self.label2:setString("尽管发生过不少不愉快的事情")
        end
    elseif self.animationTime < _pageTimestamps[7] then
        if self.currentPage == 6 then
            self.currentPage = 7
            self.photo2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo1:setVisible(true)
            self.label1:setVisible(true)
            self.photo1:setOpacity(0)
            self.label1:setOpacity(0)
            self.photo1:runAction(FadeIn.create(1500))
            self.label1:runAction(FadeIn.create(1500))
            self.photo1:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo1:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo1:setPosition(Vector2.new(__gWidth / 3.0, __gHeight / 2))
            self.label1:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label1:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label1:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label1:setString("但我相信我们总能雨过天晴")
        end
    elseif self.animationTime < _pageTimestamps[8] then
        if self.currentPage == 7 then
            self.currentPage = 8
            self.photo1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo2:setVisible(true)
            self.label2:setVisible(true)
            self.photo2:setOpacity(0)
            self.label2:setOpacity(0)
            self.photo2:runAction(FadeIn.create(1500))
            self.label2:runAction(FadeIn.create(1500))
            self.photo2:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo2:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo2:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label2:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label2:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label2:setPosition(Vector2.new(0.0, __gHeight / 2))
            self.label2:setString("我很喜欢你说过的一句话：我们一直都还是热恋期")
        end
    elseif self.animationTime < _pageTimestamps[9] then
        if self.currentPage == 8 then
            self.currentPage = 9
            self.photo2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label2:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))

            self.photo1:setVisible(true)
            self.label1:setVisible(true)
            self.photo1:setOpacity(0)
            self.label1:setOpacity(0)
            self.photo1:runAction(FadeIn.create(1500))
            self.label1:runAction(FadeIn.create(1500))
            self.photo1:setSpriteFrame(self.photoSpriteFrames[self.currentPage])
            -- 1920x1280
            self.photo1:setContentSize(Size.new(__gWidth * 2.0 / 3.0 - 60.0, 1280.0 / 1920.0 * (__gWidth * 2.0 / 3.0 - 60.0)))
            self.photo1:setPosition(Vector2.new(__gWidth / 3.0, __gHeight / 2))
            self.label1:setLabelSize(__gWidth / 3.0 - 20.0, 0.0)
            self.label1:setAnchorPoint(Vector2.new(0.0, 0.5))
            self.label1:setPosition(Vector2.new(__gWidth * 2.0 / 3.0, __gHeight / 2))
            self.label1:setString("从今往后，我要光明正大喊你老婆啦！")
        end
    elseif self.animationTime < _pageTimestamps[10] then
        if self.currentPage == 9 then
            self.currentPage = 10
            self.photo1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
            self.label1:runAction(Sequence.create({ FadeOut.create(500), Hide.create() }))
        end
    elseif self.animationTime >= _pageTimestamps[11] then
        self.firstInit = true
    end
end

function Slide:onDestroy()
    for index = 1, 9 do
        self.photoSpriteFrames[index]:release()
    end
end