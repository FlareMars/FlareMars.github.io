require('network_mgr')
require('blessingmotor')
require('slide')

MAX_MOTOR_COUNT = 4

function onNetworkCommand(content)
    if content == 'start' then
        __gMotorCount = MAX_MOTOR_COUNT * 2 + 1
        __gCanvas:clearAllChildren()

        local bg = UILayer.create(Color4B.new(255, 255, 255, 255), Size.new(__gWidth, __gHeight))
        bg:setPosition(Vector2.new(__gWidth / 2, __gHeight / 2))
        __gCanvas:addChild(bg)

        local slide = Slide.new()
        __gCanvas:addChild(slide) 
    end
end

function initialize(width, height, viewportX, viewportY, viewportWidth, viewportHeight, initialParams)
    __gWidth = width
    __gHeight = height

    local roomId = 19078936
    local appId = "f597f64cd0d052de"
    local secret = "f566612ad92b65b16bbb4ae2d86d0a3d"
    local domain = "ws://ws-apiext.huya.com/index.html?do=comm&"

    _network = NetworkManager.new()
    _network:initialize(roomId, appId, secret, domain, onNetworkCommand)

    __gCanvas = Canvas.create(Size.new(width, height))
    addChild(__gCanvas)

    local bgtexture = Texture2D.createWithFile(gResourceRootPath.."/bg.jpg", false)
    local bgspriteFrame = SpriteFrame.createWithTexture(bgtexture)
    local bg = UIImage.createWithSpriteFrame(bgspriteFrame)
    bg:setContentSize(Size.new(width, height))
    bg:setAnchorPoint(Vector2.new(0.0, 0.0))
    bg:setPosition(Vector2.new(0.0, 0.0))
    bg:setRenderMode(UIImageRenderMode.UIIMAGE_RENDERMODE_PRESERVE_ASPECT_RATIO_AND_FILL)
    __gCanvas:addChild(bg)

    __gMotorCount = 0
    __gMotorGeneratorCooldown = 0
end

function update(elapsedTime, timeSinceLastFrame, detectionInfo)
    __gMotorGeneratorCooldown = __gMotorGeneratorCooldown - timeSinceLastFrame
    if __gMotorCount < MAX_MOTOR_COUNT and __gMotorGeneratorCooldown < 0 then
        __gMotorGeneratorCooldown = 2000
        __gMotorCount = __gMotorCount + 1
        local motor = BlessingMotor.new()
        __gCanvas:addChild(motor)
    end
end

function finalize()
    _network:finalize()
end